import { Configuration, OpenAIApi } from "openai";
import express from "express";
import bodyParser  from "body-parser";
import cors from "cors";

const configuration = new Configuration({
    apiKey: "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"
});

const openai = new OpenAIApi(configuration);
const app = express();
const port = 3500;
app.use(bodyParser.json());
app.use(cors());
app.get("/",async(req,res)=>{

    const completion = await openai.createChatCompletion({
        model: "gpt-3.5-turbo",
        messages: [{ role: "system", content: "You are a helpful assistant." }, { role: "user", content: "Hello World" }]
    })

    res.json({completion:completion.data.choices[0].message.content})
})

app.listen(port,()=>{
    console.log(`App listening on:${port}`)
})
